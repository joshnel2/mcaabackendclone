module.exports = {
  contractAddress: "0xA3fC7eA538549101c420Df9a73Bc57d5fF7C8AF6",
  infuraID: "430d378c6f484c18838cd6256f7fa4c2",
  Abi: require("./abi.json"),
};
